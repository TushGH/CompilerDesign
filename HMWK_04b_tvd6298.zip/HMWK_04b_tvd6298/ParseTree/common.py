# Deshpande Tushar V.
# dalioba
# 2018-10-02
#---------#---------#---------#---------#---------#--------#
# Definitions, etc., that are common among the ParseTree
# classes.

INDENTSTR = '  '

#---------#---------#---------#---------#---------#--------#
